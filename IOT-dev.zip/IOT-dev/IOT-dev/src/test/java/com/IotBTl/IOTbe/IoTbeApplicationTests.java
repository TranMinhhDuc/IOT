package com.IotBTl.IOTbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IoTbeApplicationTests {

	@Test
	void contextLoads() {
	}

}
