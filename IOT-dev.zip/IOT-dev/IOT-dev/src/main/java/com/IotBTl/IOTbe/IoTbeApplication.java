package com.IotBTl.IOTbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IoTbeApplication {

	public static void main(String[] args) {
		SpringApplication.run(IoTbeApplication.class, args);
	}

}
