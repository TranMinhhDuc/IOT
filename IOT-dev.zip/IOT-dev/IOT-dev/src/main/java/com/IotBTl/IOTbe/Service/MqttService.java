package com.IotBTl.IOTbe.Service;

import com.IotBTl.IOTbe.config.MqttConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MqttService {

    //@Autowired
    private MqttConfig mqtt;



}
